<!DOCTYPE html>
<html>
<head>
    <title>Teacher Detail</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="mb-4 text-center">Teacher Detail</h2>

    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <h4>{{ $teacher->full_name }}</h4>
        </div>
        <div class="card-body">
            <p><strong>ID:</strong> {{ $teacher->tid }}</p>
            <p><strong>Gender:</strong> {{ $teacher->gender }}</p>
            <p><strong>Degree:</strong> {{ $teacher->degree }}</p>
            <p><strong>Tel:</strong> {{ $teacher->tel }}</p>
        </div>
        <div class="card-footer text-end">
            <a href="{{ route('teachers.index') }}" class="btn btn-secondary">Back to List</a>
        </div>
    </div>
</div>

<!-- Optional Bootstrap JS for interactive components -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
