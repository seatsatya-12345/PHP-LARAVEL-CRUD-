<!DOCTYPE html>
<html>
<head>
    <title>Teacher List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.27/dist/sweetalert2.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2>Teacher List</h2>

    <!-- Create Button -->
    <a href="{{ route('teachers.create') }}" class="btn btn-success mb-3">Add New Teacher</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Gender</th>
                <th>Degree</th>
                <th>Tel</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($teachers as $t)
            <tr>
                <td>{{ $t->tid }}</td>
                <td>{{ $t->full_name }}</td>
                <td>{{ $t->gender }}</td>
                <td>{{ $t->degree }}</td>
                <td>{{ $t->tel }}</td>
                <td>
                    <!-- Show Button -->
                    <a href="{{ route('teachers.show', $t->tid) }}" class="btn btn-info btn-sm">Show</a>

                    <!-- Edit Button -->
                    <a href="{{ route('teachers.edit', $t->tid) }}" class="btn btn-primary btn-sm">Edit</a>

                    <!-- Delete Form -->
                    <form action="{{ route('teachers.destroy', $t->tid) }}" method="POST" class="d-inline delete-form">
                        @csrf
                        @method('DELETE')
                        <button type="button" class="btn btn-danger btn-sm btn-delete">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>

<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.27/dist/sweetalert2.all.min.js"></script>
<script>
    // Attach event to all delete buttons
    document.querySelectorAll('.btn-delete').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const form = this.closest('form');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit(); // Submit the form if confirmed
                }
            });
        });
    });
</script>
</body>
</html>
