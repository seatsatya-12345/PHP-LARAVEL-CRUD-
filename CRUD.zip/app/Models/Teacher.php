<?php

namespace App\Models;

use Faker\Factory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Teacher extends Model
{
    use HasFactory;
    protected $primaryKey = 'tid';
    
    protected $fillable = [ 
        "full_name",
        'gender',
        'degree',
        'tel',
    ];
    //
}
